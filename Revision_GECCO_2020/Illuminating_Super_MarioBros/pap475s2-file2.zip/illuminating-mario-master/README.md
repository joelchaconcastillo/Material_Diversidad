# illuminating-mario
 Platform for testing illumination algorithms within the domain of procedural level generation for Super Mario Bros
 
 Designed to work with the Mario AI Benchmark (https://github.com/amidos2006/Mario-AI-Framework)
