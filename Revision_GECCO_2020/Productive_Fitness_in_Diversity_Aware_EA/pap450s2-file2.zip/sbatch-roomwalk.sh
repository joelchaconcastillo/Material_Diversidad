#!/bin/bash
#SBATCH --partition=All
#SBATCH --job-name=fpfroomwalk
#SBATCH --ntasks=1 --nodes=1
#SBATCH --mem-per-cpu=12000
cd ~/evolib3/instances/
python3 pf-roomwalk2.py